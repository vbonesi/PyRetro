# PyRetro — revisão Drive × GitHub e preparação Nitro/celular

Data: 15/10/2026. **Pacote preparado; não instalado nem publicado no GitHub.**
A pasta local foi removida deliberadamente e continua ausente. A revisão
ocorreu em `/tmp/pyretro-review-20261015-A03O43`, fora das pastas sincronizadas.
Nenhum serviço pessoal foi reinstalado, nenhuma configuração do Insync foi
alterada e nenhum acervo foi modificado.

## Resultado da comparação

Fonte: [PyRetro no Drive](https://drive.google.com/drive/folders/1GEBX_CcxBRqpfGNzcLTRk8ncThqAfeYB).
Linha de base: [GitHub main em f7214f6](https://github.com/vbonesi/PyRetro/tree/f7214f662f05abd629d14a6359d962c69767e041),
confirmada por clone HTTPS e `git ls-remote` nesta revisão.

Foram baixados e conferidos por bytes/SHA-256 **62 arquivos permitidos**:
59 dos 60 arquivos rastreados pelo GitHub, favicon novo e os dois contextos
ignorados AGENTS.md/CLAUDE.md. O único rastreado não baixado foi o marcador
vazio `logs/.gitkeep`; logs reais não foram acessados. A documentação
histórica PATHFINDER foi comparada e coincide com o GitHub.

**12 arquivos rastreados alterados + 1 arquivo de produto novo**, sem contar
AGENTS.md e CLAUDE.md, que são ignorados pelo Git. Os outros **47 rastreados
comparados coincidem**. A comparação é da árvore de arquivos: o `.git` do
Drive não foi baixado; não se afirma um número de commits locais não publicados.
Datas de modificação foram usadas como contexto, não como prova de equivalência.

| Arquivo rastreado | Diferença |
|---|---|
| `README.md` | alterado |
| `core/sortear.py` | alterado |
| `core/library.py` | alterado |
| `gui/server.py` | alterado |
| `tests/test_api.py` | alterado |
| `tests/test_app.html` | alterado |
| `tests/test_library.py` | alterado |
| `gui/static/app.js` | alterado |
| `gui/static/logic.js` | alterado |
| `gui/static/style.css` | alterado |
| `gui/static/index.html` | alterado |
| `docs/changelog.md` | alterado |

Arquivo novo: `gui/static/favicon.svg`. Contextos ignorados presentes somente
no Drive: `AGENTS.md` e `CLAUDE.md`; ambos continham estados antigos sobre
HEAD, serviço e sincronização. Não são diferenças de produto a publicar.

### Comportamentos ainda ausentes do GitHub

- **Progresso sem F5:** gravações assíncronas em sequência e atualização da
  biblioteca/filtros/cards após concluir a cascata de iniciado/finalizado/platinado.
- **Rolagem e alças:** aplicação fixa na janela, rolagem interna da galeria,
  recolhimento independente de menu e filtros e uma alça quando ambos recolhidos.
- **Desejados:** registros apenas `wishlist:*` saem da Biblioteca e do sorteio;
  uma compra atualiza a Biblioteca. A regra já existente no Drive converte PSN
  genérico em PS4, preservando plataformas específicas. Nenhum registro real
  foi convertido nesta revisão.
- **ROM pesada:** nome de exibição sem extensão; nome real permanece nas ações.
- **Sorteio:** exibição da plataforma da Biblioteca.
- **Favicon SVG:** recurso novo, referência no HTML e MIME correspondente no servidor.
- **Documentação/testes:** README e changelog acompanham as alterações; o Drive
  tem quatro testes Python e dez testes de interface a mais que o publicado.

## Correções preparadas sobre a versão do Drive

1. **Política de destinos efetiva:** novo `config.nitro.example.toml` com
   PS2/NGC/WII somente `pc` (Nitro) e NDS/3DS somente `android`. A CLI e a GUI
   recusam envio de PS2/GC/Wii ao celular antes de iniciar adb/job; os cards
   deixam de oferecer esse envio. DS não gera playlist no PC; `all` respeita
   o destino permitido. Outros sistemas e configurações antigas conservam
   seu comportamento. Download e gestão de DS/3DS no Nitro continuam possíveis
   como staging, sem significar emulação no notebook.
2. **Identidade no sorteio:** reproduzido com dois jogos fictícios de mesmo
   nome: o filtro `biblioteca:xbox` retornava `plataforma=Steam`. O pool e o
   filtro de gênero agora preservam o ID; a resposta resolve a cópia sorteada,
   inclusive a capa. O campo público `codigo` continua nulo para Biblioteca.
3. **Configuração sem pressupor dados privados:** o modelo usa pasta local
   de ROMs/staging e não registra cards nem habilita o caminho de backup
   Dolphin antes de validação. Nenhum caminho foi confirmado pela leitura da
   configuração privada anterior. O perfil só se ativa quando usado no destino;
   não configura emuladores nem identifica fisicamente o Nitro.
4. **Documentação atual:** guia `docs/NITRO-CELULAR.md`, aviso no README e
   roadmap, changelog datado e helper `tools/test-ui-isolated.py` para testar
   a GUI sem usar configuração/biblioteca reais.

A cópia preparada preserva as 12 alterações e o favicon do Drive. Os patches
separam esse material recuperado das mudanças produzidas nesta revisão.
Nenhum arquivo-fonte existente do Drive foi substituído por este pacote.

## Correções/decisões restantes antes de uso real

- **Download de pastas precisa de correção própria.** O downloader existente
  usa `rclone copy origem staging` e depois procura `staging/nome_da_pasta`.
  Em cópia de diretório, o conteúdo vai diretamente ao destino; uma simulação
  controlada reproduziu a mensagem “rclone terminou mas o arquivo não apareceu
  no staging”. O staging também é compartilhado entre itens. Antes de homologar
  downloads de pastas, usar staging isolado por job, destino explícito para
  arquivo/pasta e conferir novamente a existência do destino antes de concluir.
  Este mecanismo antigo não foi alterado neste pacote; downloads reais não
  foram executados, nem de arquivos nem de pastas.
- **Saves não são decididos pela divisão de emulação.** O código mantém rotas
  antigas de Dolphin/PS2 entre PC e Android; não executar `emu-sync all --apply`
  para migrar. Definir fonte, destino e único gravador para cada save/card;
  conferir formatos/versões e pastas dos emuladores no Nitro. DS/3DS não
  ganham um backup homologado com essa preparação.
- **Frontend depende do setup.** ES-DE e Steam Big Picture continuam proposta.
  Instalação, controles, TV, atalhos e adaptação dos códigos/pastas ficam no
  setup. Não existe adaptador/exportador nem sincronização automática de
  progresso de frontend neste pacote.
- **Hardware e conta reais pendentes:** sandboxes/permissões, controles, Wii
  por jogo, TV e acesso remoto precisam da validação no destino; testes
  sintéticos não comprovam desempenho nem funcionamento no aparelho.

## Fronteira de responsabilidades

| Componente | Responsabilidade |
|---|---|
| PyRetro | gestão do acervo, catálogo, downloads, organização, capas e progresso |
| setup-linux | instalar/configurar emuladores e frontend, atalhos, controle, TV e permissões |
| frontend escolhido | navegar/iniciar jogos locais prontos, somente sistemas permitidos naquele dispositivo |
| emulador | executar o jogo e gravar seus próprios saves, com destino validado |

Frontend sem acesso a `library.json` ou credenciais, sem escrita de progresso,
sem iniciar downloads e sem renomear/apagar a origem. DS/3DS ficam fora das
entradas de emulação do Nitro; cópias locais para envio/gestão não devem ser
indexadas como jogos executáveis. Evitar duplicar ES-DE e atalhos individuais
na Steam. A política de saves permanece um trabalho separado.

## Testes e evidências

| Revisão | Python | Interface |
|---|---:|---:|
| GitHub f7214f6 | 145 passaram | não reexecutada nesta revisão |
| Drive, antes de alterações | 149 passaram | 33 passaram |
| Cópia preparada | 161 passaram | 35 passaram |

Testes HTTP reais em localhost com fixtures temporárias; chamadas a adb/rclone
nos novos casos são mockadas. O teste do sorteio falhou antes e passou com a
correção. Os testes de envio recusado verificam que nenhum job/adb é iniciado.
A suíte de interface foi executada no navegador integrado Chromium; não foi
homologada em celular físico. `git apply --check` e aplicação do patch completo
sobre uma cópia de f7214f6 passaram; os bytes resultantes coincidiram com a
árvore preparada e `git diff --check` não encontrou problemas.

`comparacao-fontes.json` contém IDs/URLs, tamanhos, datas e SHA-256 dos arquivos
baixados, sem URLs temporárias de download. Logs de testes e reproduções
sintéticas acompanham o pacote. Não é certificação de todo o Drive ou das
áreas excluídas, nem revisão de todo comportamento antigo do aplicativo.

## Roteiro de validação no destino

O passo a passo completo está em `preparado/docs/NITRO-CELULAR.md`:

1. Conferir SHA-256 do pacote e arquivos; usar checkout isolado no commit-base.
2. Conferir/aplicar o patch e rodar Python e GUI com fixtures antes de apontar
   qualquer serviço para dados pessoais. O helper imprime uma URL localhost.
3. Somente no Nitro, revisar o modelo de configuração sem sobrescrever uma
   configuração existente; informar contas manualmente no destino.
4. Conferir bloqueio PS2/GC/Wii → celular e DS → playlist PC; validar a ida de
   3DS ao celular e excluir DS/3DS do frontend do Nitro.
5. Pelo setup, configurar PCSX2/Dolphin, pastas/permissões e controles; planejar
   a migração dos saves separadamente, com emuladores fechados.
6. Com itens escolhidos pelo Victor, abrir/salvar/fechar/reabrir um jogo por
   plataforma no dispositivo correto; depois validar controle, saída do jogo
   e sessão na TV. Homologar também a GUI completa pelo celular.
7. Validar a estratégia de frontend/atalhos e somente então configurar
   inicialização automática/acesso remoto no Nitro.

Não há instalação, sincronização reativada, commit/push, publicação de acervo
ou alteração de saves como parte desta entrega.

## Conteúdo do pacote

- `01-drive-nao-publicado.patch`: GitHub f7214f6 → árvore de produto do Drive.
- `02-preparacao-sobre-drive.patch`: árvore do Drive → preparação desta revisão.
- `03-completo-sobre-github-f7214f6.patch`: resultado combinado para o commit-base.
- `fonte-drive/`: fonte revisada, sem contextos ignorados/dados privados.
- `preparado/`: código, modelo de configuração e guia preparados.
- `comparacao-fontes.json`, logs, resultado da interface e `SHA256SUMS`.

Os patches não incluem `.git` do Drive, configuração privada, biblioteca,
backups, caches pessoais ou inventários de acervo. A revisão técnica e o
pacote ficam na documentação do projeto no Drive; não foi criada uma base
paralela de notas pessoais.

Referências verificadas para o roteiro:
[PCSX2](https://pcsx2.net/docs/setup/running/),
[memory cards do PCSX2](https://github.com/PCSX2/pcsx2-net-www/blob/main/docs/configuration/memcards.md),
[controles Dolphin](https://dolphin-emu.org/docs/guides/configuring-controllers/).
