"""Política de destinos com fixtures; nenhum dispositivo/conta real."""
import copy
import sys
import tomllib
import unittest
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).parent.parent))
from core import device_policy as policy
import retrosync
from test_api import BaseAPI, lm, srv


class TestPolicy(unittest.TestCase):
    def setUp(self):
        self.cfg = tomllib.loads((Path(__file__).parent.parent / "config.nitro.example.toml").read_text())

    def test_nitro_e_celular_tem_destinos_exclusivos(self):
        for code in ("PS2", "NGC", "WII"):
            self.assertTrue(policy.allowed(self.cfg, code, "pc"))
            self.assertFalse(policy.allowed(self.cfg, code, "android"))
        for code in ("NDS", "3DS"):
            self.assertFalse(policy.allowed(self.cfg, code, "pc"))
            self.assertTrue(policy.allowed(self.cfg, code, "android"))

    def test_outros_sistemas_e_config_antigo_conservam_destinos(self):
        self.assertEqual(policy.playlist_targets(self.cfg, "PSP", "all"), ["pc", "android"])
        del self.cfg["device_policy"]
        self.assertEqual(policy.playlist_targets(self.cfg, "PS2", "all"), ["pc", "android"])

    def test_all_respeita_destinos_e_pc_explicitamente_proibido_e_recusado(self):
        self.assertEqual(policy.playlist_targets(self.cfg, "NDS", "all"), ["android"])
        with self.assertRaisesRegex(ValueError, "NDS"):
            policy.playlist_targets(self.cfg, "NDS", "pc")

    def test_politica_invalida_nao_libera_destino(self):
        for devices in ([], "android", ["android", "outro"], [True]):
            cfg = copy.deepcopy(self.cfg)
            cfg["device_policy"]["targets"]["NDS"] = devices
            with self.assertRaises(ValueError):
                policy.allowed(cfg, "NDS", "pc")
        self.cfg["device_policy"]["targets"]["TYPO"] = ["pc"]
        with self.assertRaisesRegex(ValueError, "desconhecido"):
            policy.validate(self.cfg)

    def test_template_nao_habilita_cards_ou_backup_sem_validacao(self):
        self.assertEqual(self.cfg["pc"]["dolphin_data_root"], "")
        self.assertEqual(self.cfg["memcards"]["ps2"], {})
        for section, keys in {"steam": ["api_key", "steamid64"], "steamgriddb": ["api_key"],
                              "psn": ["npsso"], "xbox": ["api_key"],
                              "screenscraper": ["member_id", "member_password", "dev_id", "dev_password"]}.items():
            for key in keys:
                self.assertEqual(self.cfg[section][key], "")

    def test_cli_envio_proibido_para_antes_de_rclone_adb_ou_scan(self):
        with patch.object(retrosync, "load_config", return_value=self.cfg), \
             patch.object(retrosync.heavy_mod, "list_local") as local, \
             patch.object(retrosync.heavy_mod, "list_drive_items") as drive, \
             patch.object(retrosync.adb_mod, "ensure_connected") as adb:
            with self.assertRaisesRegex(SystemExit, "PS2.*desabilitado"):
                retrosync.cmd_heavy_roms(SimpleNamespace(system="PS2", send="Jogo.iso"))
            local.assert_not_called(); drive.assert_not_called(); adb.assert_not_called()

    def test_playlist_pc_de_nds_nao_varre_rom_nem_conecta_adb(self):
        with patch.object(retrosync, "load_config", return_value=self.cfg), \
             patch.object(retrosync.playlist_mod, "list_local_names") as local, \
             patch.object(retrosync.adb_mod, "ensure_connected") as adb:
            with self.assertRaisesRegex(SystemExit, "NDS.*desabilitado"):
                retrosync.cmd_rebuild_playlist(SimpleNamespace(system="NDS", target="pc", apply=True))
            local.assert_not_called(); adb.assert_not_called()

    def test_gui_playlist_all_de_nds_usa_so_android(self):
        messages = []
        with patch.object(srv, "load_config", return_value=self.cfg), \
             patch.object(srv.playlist_mod, "list_local_names") as local, \
             patch.object(srv.playlist_mod, "list_remote_names", return_value=[]) as remote, \
             patch.object(srv.adb_mod, "ensure_connected", return_value="synthetic"):
            srv.run_rebuild_playlist_job(messages.append, "NDS", "all", False)
            local.assert_not_called(); remote.assert_called_once()
        self.assertTrue(any("permitidos: android" in e.get("line", "") for e in messages))


class TestPolicyHTTP(BaseAPI):
    def setUp(self):
        cfg = srv.CONFIG_PATH.read_text()
        if "[device_policy.targets]" not in cfg:
            srv.CONFIG_PATH.write_text(cfg + '\n[device_policy.targets]\nPS2 = ["pc"]\n')
        self.gravar_biblioteca([])

    def test_http_envio_ps2_recusa_antes_de_iniciar_job(self):
        with patch.object(srv, "_run_exclusive_heavy_send") as send:
            status, response = self.pedir("/api/heavy/send", {"code": "PS2", "name": "Ficticio.iso"})
            self.assertEqual(status, 400)
            self.assertIn("desabilitado", response["error"])
            send.assert_not_called()

    def test_listagem_ps2_sem_adb_com_botao_envio_desabilitado(self):
        with patch.object(srv.adb_mod, "ensure_connected") as adb:
            status, response = self.pedir("/api/heavy/roms/PS2")
            self.assertEqual(status, 200)
            self.assertFalse(response["android_allowed"])
            self.assertTrue(response["items"])
            self.assertFalse(response["items"][0]["android_allowed"])
            adb.assert_not_called()


class TestLotteryIdentityHTTP(BaseAPI):
    def test_filtro_xbox_nao_devolve_plataforma_da_copia_steam(self):
        steam = lm._blank_game("Mesmo nome", "Steam"); steam["fontes"] = ["steam"]
        xbox = lm._blank_game("Mesmo nome", "Xbox"); xbox["fontes"] = ["xbox"]
        self.gravar_biblioteca([steam, xbox])
        status, result = self.pedir("/api/sortear?system=biblioteca:xbox")
        self.assertEqual(status, 200)
        self.assertEqual(result["plataforma"], "Xbox")
        self.assertIsNone(result["codigo"])

    def test_genero_casa_com_id_da_plataforma_sorteada(self):
        steam = lm._blank_game("Mesmo nome", "Steam"); steam["fontes"] = ["steam"]; steam["genero"] = "Ação"
        xbox = lm._blank_game("Mesmo nome", "Xbox"); xbox["fontes"] = ["xbox"]; xbox["genero"] = "RPG"
        self.gravar_biblioteca([steam, xbox])
        status, result = self.pedir("/api/sortear?system=biblioteca:xbox&genero=RPG")
        self.assertEqual(status, 200)
        self.assertEqual(result["plataforma"], "Xbox")
        self.assertEqual(self.pedir("/api/sortear?system=biblioteca:pc&genero=RPG")[0], 404)
