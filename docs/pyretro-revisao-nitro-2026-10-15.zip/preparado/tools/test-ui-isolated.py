"""Servidor de testes com fixtures; não carrega config/biblioteca do usuário."""
import sys
import threading
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent / "tests"))
from test_api import BaseAPI


def main():
    BaseAPI.setUpClass()
    try:
        BaseAPI().gravar_biblioteca([])
        print(BaseAPI.url + "/tests/test_app.html", flush=True)
        print("Somente fixtures temporárias. Ctrl+C para encerrar.", flush=True)
        threading.Event().wait()
    except KeyboardInterrupt:
        pass
    finally:
        BaseAPI.tearDownClass()


if __name__ == "__main__":
    main()
