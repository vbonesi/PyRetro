"""Destinos de jogos/playlists; não altera acervo nem política de saves.

Sem a seção opcional device_policy, preserva o comportamento existente.
O destino pc deste perfil representa o Nitro; não instala emuladores.
"""


def validate(cfg: dict) -> None:
    policy = cfg.get("device_policy", {})
    if not isinstance(policy, dict):
        raise ValueError("device_policy deve ser uma tabela")
    targets = policy.get("targets", {})
    if not isinstance(targets, dict):
        raise ValueError("device_policy.targets deve ser uma tabela")
    known = set(cfg.get("systems", {})) | set(cfg.get("heavy_systems", {}))
    for code, devices in targets.items():
        if code not in known:
            raise ValueError(f"device_policy: sistema desconhecido: {code}")
        if (not isinstance(devices, list) or not devices
                or any(d not in ("pc", "android") for d in devices)):
            raise ValueError(f"device_policy: destinos inválidos para {code}")


def allowed(cfg: dict, code: str, target: str) -> bool:
    validate(cfg)
    if target not in ("pc", "android"):
        raise ValueError(f"destino desconhecido: {target}")
    return target in cfg.get("device_policy", {}).get("targets", {}).get(code, ["pc", "android"])


def require(cfg: dict, code: str, target: str) -> None:
    if not allowed(cfg, code, target):
        raise ValueError(f"{code}: destino {target} desabilitado pela política de dispositivos")


def playlist_targets(cfg: dict, code: str, requested: str) -> list[str]:
    if requested == "all":
        return [t for t in ("pc", "android") if allowed(cfg, code, t)]
    require(cfg, code, requested)
    return [requested]
