# PyRetro no Nitro e emulação no celular

Preparação de 15/10/2026. Perfil testado com dados sintéticos; não instalado
no Nitro nem homologado no celular. O PyRetro roda no Nitro e o celular usa
a GUI como cliente. A trilha Termux continua descontinuada.

## Destinos e configuração

| Código PyRetro | Emulação | Gestão/download no Nitro |
|---|---|---|
| PS2 | somente Nitro, PCSX2 pelo setup | sim |
| NGC | somente Nitro, Dolphin Emulator pelo setup | sim |
| WII | somente Nitro, Dolphin Emulator pelo setup | sim |
| NDS | somente celular | staging e gestão permitidos |
| 3DS | somente celular | staging e gestão permitidos |
| Outros | conservar as decisões existentes | conservar |

Use `config.nitro.example.toml` como modelo **somente no Nitro**. Ele não
instala nada e não se ativa por existir. O mapeamento precisa estar no
`config.toml` usado pelo PyRetro. Os caminhos são exemplos, sem leitura da
configuração privada anterior. O destino `pc` representa o Nitro neste perfil;
não há identificação física do notebook nem bloqueio do próprio emulador.

O código pode morar fora de qualquer pasta sincronizada. O modelo separa
`~/Games/PyRetro/ROMs` para conteúdo local/staging e
`~/Games/PyRetro/staging` para download intermediário. O catálogo remoto
continua em `Jogos/ROMs` no Drive. Confirmar esses caminhos no destino.
Não apontar o frontend para a raiz do Drive ou para o staging de DS/3DS.

A seção opcional `[device_policy.targets]` é lida pela CLI e GUI:

- PS2/NGC/WII: envio ao Android recusado antes de iniciar um job/adb;
  listagem deixa de consultar adb e o card não oferece Enviar/Reenviar.
- NDS: `rebuild-playlist --target pc` é recusado; `--target all` utiliza
  somente Android. A mesma seleção de destinos vale para a GUI.
- 3DS continua como sistema pesado; não há criação de playlist RetroArch
  para ele. Sua emulação fica no app do celular, escolhido/validado lá.
- Aquisição, catálogo, capas, organização e tracking continuam disponíveis
  para todos esses sistemas. Download de 3DS para staging não significa
  suporte a executar 3DS no Nitro.
- Sem essa seção, a configuração antiga conserva seu comportamento.

Nenhum jogo, save, configuração de emulador ou atalho existente é removido.
O perfil não impede que alguém execute manualmente outro emulador fora do
PyRetro; a exclusão de DS/3DS do frontend é responsabilidade do setup.

## Fronteira com o frontend do setup

| Responsável | Escopo |
|---|---|
| PyRetro | acervo, catálogo, obtenção/downloads, organização, capas, biblioteca e progresso |
| setup-linux | instalação de emuladores/frontend, atalhos, controle, tela cheia, TV e permissões de acesso às pastas |
| frontend | navegar e iniciar jogos locais já disponibilizados pelo PyRetro |
| emulador | execução e gravação dos próprios saves; configurar no Nitro após a migração |

ES-DE via Steam Big Picture permanece proposta do setup; não foi escolhido
nem instalado aqui. Evitar duplicar a entrada ES-DE e atalhos individuais
via Steam ROM Manager sem definir uma única estratégia no setup.

Contrato para uma integração posterior: o frontend recebe apenas caminhos
locais de jogos prontos e sistemas permitidos para `pc`; para esta divisão,
PS2/NGC/WII entram, NDS/3DS ficam fora. A integração deve adaptar os códigos
do PyRetro aos códigos do frontend escolhido, sem renomear o acervo.
Não há exportador/adaptador implementado neste pacote.

O frontend não lê nem escreve `library.json`, não recebe credenciais,
não dispara downloads nem altera notas, horas, iniciado/finalizado/platinado.
Não há sincronização de progresso frontend → PyRetro nesta preparação.
Abrir/fechar um emulador não deve marcar progresso automaticamente.
Capas e metadados exportados, se isso for implementado depois, serão cópias
derivadas; uma nova varredura não pode renomear/apagar os arquivos de origem.

## Saves: decisão separada

A divisão de emulação não muda automaticamente a política de backup.
O modelo deixa `dolphin_data_root` vazio e os cards sem registro até conferir
os destinos reais. Isso deixa o perfil incompleto para a tela de saves por
decisão explícita de preparação; não autoriza criar cards vazios sobre os antigos.

Não executar `emu-sync all --apply`, backup de saves ou importação de cards
como atalho de migração. `emu-sync` ainda descreve PS2/Dolphin entre PC e
Android; `backup-config` cobre RetroArch, não todos os emuladores standalone.
DS/3DS também não ganham backup de saves homologado por esta configuração.
Primeiro decidir, com os emuladores fechados, quais saves permanecem no
celular, quais migram uma vez e qual processo será o único gravador de cada
destino. Nenhum backup real foi aberto nesta revisão.

## Validação no destino

1. Preservar o pacote de revisão; conferir o `SHA256SUMS`. Montar uma cópia
   de código fora do acervo e da sincronização, partindo do GitHub no commit
   indicado no relatório e aplicando o patch completo com `git apply --check`
   antes de aplicar. Se o HEAD mudou, reconciliar o diff antes de usar.
2. Rodar `python3 -m unittest discover -s tests -v`. Usar o helper
   `tools/test-ui-isolated.py` para abrir `/tests/test_app.html` com fixtures;
   ele não precisa de configuração, biblioteca ou credenciais reais.
   Conferir resultado no navegador desktop e na largura do celular.
3. Somente no Nitro: revisar caminhos do modelo e criar a configuração local
   sem sobrescrever uma existente. Configurar contas manualmente; não copiar
   credenciais da máquina antiga. Não ativar o backend antes de conferir que
   cada raiz pertence ao domínio pessoal e ao destino esperado.
4. Com fixtures: conferir ausência do envio ao celular para PS2/NGC/WII;
   exigir recusa também por HTTP/CLI. Conferir envio de 3DS ao celular e
   playlist de DS somente Android. A existência de staging local não deve
   fazer DS/3DS aparecerem como emulação no frontend do Nitro.
5. Pelo setup, instalar/abrir PCSX2 e Dolphin e conferir as pastas efetivas e
   permissões do sandbox. Confirmar BIOS e arquivos próprios de configuração
   no destino, sem incluí-los em patches ou Git. Definir separadamente a
   migração de cards/saves antes de apontar para qualquer pasta preservada.
6. Com um jogo por plataforma selecionado pelo Victor: PS2/GC/Wii no Nitro;
   DS/3DS no celular. Testar abrir, salvar, fechar e reabrir o progresso no
   emulador. Anotar versão e configuração usadas; não prometer equivalência
   entre savestates de versões/emuladores diferentes.
7. Validar controle Xbox, saída/retorno do jogo, foco da janela e uma sessão
   na TV (resolução/frequência/áudio reais). Para Wii, conferir por jogo o
   perfil de Wii Remote/Nunchuk emulados; não presumir adaptação completa
   de jogos de movimento ao controle comum.
8. Confirmar a estratégia de frontend no setup. Começar com uma entrada por
   sistema/jogo de teste; excluir DS/3DS, evitar atalhos duplicados e testar
   novamente sair do jogo e voltar à interface com controle.
9. Validar a GUI pelo celular: último card, rolagem, alças, filtros e
   atualização de progresso sem F5; conferir o botão final de cada fluxo.
   Só depois configurar inicialização automática/acesso remoto no Nitro.

Os passos que envolvem acervo/saves reais são para execução no destino com
o Victor, fora da revisão isolada. Não reativar Insync nem instalar o stack
de jogos nesta máquina de origem para cumprir esse roteiro.

Referências técnicas consultadas em 15/10/2026:
[PCSX2 — execução](https://pcsx2.net/docs/setup/running/),
[PCSX2 — memory cards](https://github.com/PCSX2/pcsx2-net-www/blob/main/docs/configuration/memcards.md),
[Dolphin — controles](https://dolphin-emu.org/docs/guides/configuring-controllers/).
